use classicmodels;

SELECT CONCAT('$', FORMAT(priceEach * quantityOrdered, 2)) AS sales_amount
FROM orderdetails;

SELECT CONCAT('$', FORMAT(SUM(priceEach * quantityOrdered) / 1000000, 2), 'M') AS total_sales
FROM orderdetails;

select * from orderdetails;

SELECT 
  CONCAT('$', FORMAT(AVG(priceEach * quantityOrdered), 2)) AS average_sales,
  CONCAT('$', FORMAT(MIN(priceEach * quantityOrdered), 2)) AS minimum_sales,
  CONCAT('$', FORMAT(MAX(priceEach * quantityOrdered), 2)) AS maximum_sales
FROM orderdetails;

SELECT 
  o.orderDate, 
  od.priceEach * od.quantityOrdered AS sales_amount
FROM orders o
JOIN orderdetails od ON o.orderNumber = od.orderNumber
WHERE o.orderDate BETWEEN '2003-01-01' AND '2005-12-31' -- Filter by a specific time period
ORDER BY sales_amount DESC; -- Sort in descending order based on sales amount

SELECT o.orderNumber, o.orderDate, c.customerName
FROM orders o
JOIN customers c ON o.customerNumber = c.customerNumber;

SELECT orderNumber, productCode, CONCAT('$', FORMAT(priceEach * quantityOrdered, 2)) AS sales
FROM orderdetails
WHERE (priceEach * quantityOrdered) > (SELECT AVG(priceEach * quantityOrdered) FROM orderdetails);

SELECT *
FROM orders
WHERE customerNumber IN (SELECT customerNumber FROM customers WHERE country = 'USA');


SELECT c.country, AVG(od.priceEach * od.quantityOrdered) AS avg_sales
FROM orderdetails od
JOIN orders o ON od.orderNumber = o.orderNumber
JOIN customers c ON o.customerNumber = c.customerNumber
WHERE c.country = 'USA'
GROUP BY c.country;

CREATE VIEW orders_in_USA AS
SELECT o.orderNumber, c.customerName, o.orderDate,
       CONCAT('$', FORMAT(SUM(od.priceEach * od.quantityOrdered) / 1000000, 2), 'M') AS total_amount
FROM orders o
JOIN customers c ON o.customerNumber = c.customerNumber
JOIN orderdetails od ON o.orderNumber = od.orderNumber
WHERE c.country = 'USA'
GROUP BY o.orderNumber, c.customerName, o.orderDate;

SELECT *
FROM orders_in_USA;

UPDATE orders
SET comments = COALESCE(comments, 'NA')
WHERE comments IS NULL;

select * from orders;






